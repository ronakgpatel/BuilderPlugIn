package pojobuilderplugin.exception;

public class NoFieldExistsException extends BuilderPlugInException {

	private static final long serialVersionUID = 1L;

	public NoFieldExistsException(String message){
		super(message);
	}
}
