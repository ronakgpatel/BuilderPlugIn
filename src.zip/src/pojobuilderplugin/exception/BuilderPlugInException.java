package pojobuilderplugin.exception;

public class BuilderPlugInException extends Exception {

	private static final long serialVersionUID = 1L;

	public BuilderPlugInException(String message){
		super(message);
	} 
}
